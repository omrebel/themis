﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Themis.System
{
    public partial class frmSystem : DevExpress.XtraEditors.XtraForm
    {
        public frmSystem()
        {
            InitializeComponent();
        }
    }
}